# Checkpoint 2
Name: Farid Hamid, Lourenco Velez
Student ID: 1067867, 1102204

# Acknowledgements
This project was build off of Professor Fei Song's C1-Package

# How to build
1. <make>
2. <java -cp /usr/share/java/cup.jar:. CM test/filename.cm> or <java -cp /usr/share/java/cup.jar:. CM test/filename.cm [-a,-s]>
3. <make clean> 

# Test Instructions
- 1.cm: <java -cp /usr/share/java/cup.jar:. CM test/1.cm> or <java -cp /usr/share/java/cup.jar:. CM test/1.cm [-a,-s]>

- 2.cm: <java -cp /usr/share/java/cup.jar:. CM test/2.cm> or <java -cp /usr/share/java/cup.jar:. CM test/2.cm [-a,-s]>

- 3.cm: <java -cp /usr/share/java/cup.jar:. CM test/3.cm> or <java -cp /usr/share/java/cup.jar:. CM test/3.cm [-a,-s]>

- 4.cm: <java -cp /usr/share/java/cup.jar:. CM test/4.cm> or <java -cp /usr/share/java/cup.jar:. CM test/4.cm [-a,-s]>

- 5.cm: <java -cp /usr/share/java/cup.jar:. CM test/5.cm> or <java -cp /usr/share/java/cup.jar:. CM test/5.cm [-a,-s]>

