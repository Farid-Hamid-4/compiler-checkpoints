package absyn;

abstract public class Var extends Absyn {
    public int getType(){
        return -1;
    }
}
